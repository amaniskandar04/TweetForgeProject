/**
 *
 * @author mamirizzan
 */
package com.example.realStart.service;

import com.example.realStart.PostBody.CommentWithUsername;
import com.example.realStart.PostBody.TweetWithUsername;
import com.example.realStart.model.Comment;
import com.example.realStart.model.RecommendedTweets;
import com.example.realStart.model.Tweet;
import com.example.realStart.model.User;
import com.example.realStart.repository.CommentRepository;
import com.example.realStart.repository.RecommendedTweetsRepository;
import com.example.realStart.repository.TweetRepository;
import com.example.realStart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import com.example.realStart.RecBase.Constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;

@Service
public class TweetService {

    @Autowired
    private TweetRepository tweetRepository;

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private UserService userService;

    @Autowired
    private RecommendedTweetsRepository recTweetsRepo;

    private Constants constant = new Constants();

    public Tweet postTweet(String content, String userId, List<String> hashtags) {
        Tweet tweet = new Tweet(content, userId, hashtags, new ArrayList<>());
        tweet = tweetRepository.save(tweet); //save the tweet to the database

        Query query = new Query(Criteria.where("_id").is(userId));
        Update update = new Update().push("tweetIds", tweet.getTweetId());

        mongoTemplate.updateFirst(query, update, User.class);

        List<String> topics = constant.getAssociatedTopics(hashtags);
        System.out.println(topics.size());

        userService.updateUserProfile(userId, topics, "like");

        return tweet;
    }

    public void likeTweet(String tweetId, String userId) {
        //update user document
        Query query = new Query(Criteria.where("_id").is(userId));
        Update update = new Update().addToSet("likeTweetIds", tweetId);
        mongoTemplate.findAndModify(query, update, User.class);

        //update tweet document
        Query tweetQuery = new Query(Criteria.where("_id").is(tweetId));
        Update tweetUpdate = new Update().addToSet("likeUserIds", userId);
        mongoTemplate.findAndModify(tweetQuery, tweetUpdate, Tweet.class);

        List<String> topics = constant.getAssociatedTopics(tweetRepository.findById(tweetId).get().getHashtags());
        userService.updateUserProfile(userId, topics, "like");
    }

    public void unlikeTweet(String tweetId, String userId) {
        //update user document
        Query query = new Query(Criteria.where("_id").is(userId));
        Update update = new Update().pull("likeTweetIds", tweetId);
        mongoTemplate.findAndModify(query, update, User.class);

        //update tweet document
        Query tweetQuery = new Query(Criteria.where("_id").is(tweetId));
        Update tweetUpdate = new Update().pull("likeUserIds", userId);
        mongoTemplate.findAndModify(tweetQuery, tweetUpdate, Tweet.class);

        List<String> topics = constant.getAssociatedTopics(tweetRepository.findById(tweetId).get().getHashtags());
        userService.updateUserProfile(userId, topics, "unlike");
    }

    public void likeComment(String commentId, String userId) {
        //update user document
        Query query = new Query(Criteria.where("_id").is(userId));
        Update update = new Update().addToSet("likeTweetIds", commentId);
        mongoTemplate.findAndModify(query, update, User.class);

        //update comment document
        Query commentQuery = new Query(Criteria.where("_id").is(commentId));
        Update commentUpdate = new Update().addToSet("likeUserIds", userId);
        mongoTemplate.findAndModify(commentQuery, commentUpdate, Comment.class);

        List<String> topics = constant.getAssociatedTopics(commentRepository.findById(commentId).get().getHashtags());
        userService.updateUserProfile(userId, topics, "like");
    }

    public void unlikeComment(String commentId, String userId) {
        //update user document
        Query query = new Query(Criteria.where("_id").is(userId));
        Update update = new Update().pull("likeTweetIds", commentId);
        mongoTemplate.findAndModify(query, update, User.class);

        //update comment document
        Query commentQuery = new Query(Criteria.where("_id").is(commentId));
        Update commentUpdate = new Update().pull("likeUserIds", userId);
        mongoTemplate.findAndModify(commentQuery, commentUpdate, Comment.class);

        List<String> topics = constant.getAssociatedTopics(commentRepository.findById(commentId).get().getHashtags());
        userService.updateUserProfile(userId, topics, "unlike");
    }

    public void deleteTweet(String tweetId) {
        mongoTemplate.update(Tweet.class)
                .matching(Criteria.where("tweetId").is(tweetId))
                .apply(new Update()
                        .set("content", "Tweet deleted by user")
                        .set("statusDelete", true)
                        .set("hashtags",Collections.emptyList()))
                .first();
    }

    public void deleteComment(String commentId) {
        mongoTemplate.update(Comment.class)
                .matching(Criteria.where("commentId").is(commentId))
                .apply(new Update().set("content", "Comment deleted by user").set("statusDelete", true))
                .first();
    }

    public void deleteLikePost(String tweetId, String userId) {
        Query tweetQuery = new Query(Criteria.where("_id").is(new ObjectId(tweetId)));
        Update tweetUpdate = new Update().pull("likeUserIds", userId);
        mongoTemplate.findAndModify(tweetQuery, tweetUpdate, Tweet.class);

        Query userQuery = new Query(Criteria.where("_id").is(new ObjectId(userId)));
        Update userUpdate = new Update().pull("likeTweetIds", tweetId);
        mongoTemplate.findAndModify(userQuery, userUpdate, User.class);
    }

    public Comment addComment(String content, String userId, String parentId, List<String> hashtags) {
        Comment comment = new Comment(content, userId, parentId, new ArrayList<>(), hashtags);
        comment = commentRepository.save(comment); // Save the comment to the database

        Query query = new Query(Criteria.where("_id").is(userId));
        Update update = new Update().push("commentIds", comment.getCommentId());

        mongoTemplate.updateFirst(query, update, User.class);

        return comment;
    }

    public List<TweetWithUsername> searchTweets(String keyword) {
        Query query = new Query();
//        String regexKeyword = keyword.startsWith("#") ? "\\Q" + keyword + "\\E" : "\\Q#" + keyword + "\\E";
//
//        // Add criteria to search for content or hashtags containing the keyword
//        query.addCriteria(new Criteria().orOperator(
//                Criteria.where("content").regex(keyword, "i"),
//                Criteria.where("hashtags").regex(regexKeyword, "i")
//        ));
        // Split the keyword string into individual hashtags
        String[] keywords = keyword.split("\\s+");

        // Create a list to hold criteria for each hashtag
        List<Criteria> keywordCriteria = new ArrayList<>();

        // Add criteria for each keyword
        for (String kw : keywords) {
            String regexKeyword = "\\Q" + kw + "\\E";
            System.out.println(regexKeyword);
            keywordCriteria.add(
                    new Criteria().orOperator(
                            Criteria.where("hashtags").is(kw),
                            Criteria.where("content").regex(regexKeyword, "i")
                    )
            );
        }

        // Combine the criteria for all keywords using OR operator
        query.addCriteria(new Criteria().andOperator(keywordCriteria.toArray(new Criteria[0])));

        List<Tweet> tweets = mongoTemplate.find(query, Tweet.class); // Executes the query and returns the list of matching Tweet documents.
        // Create a list to hold active tweets
        List<Tweet> activeTweets = new ArrayList<>();

        // Iterate through each tweet and add only those that are not deleted to the activeTweets list
        for (Tweet tweet : tweets) {
            if (!tweet.isStatusDelete()) {
                activeTweets.add(tweet);
            }
        }

        // Return the list of active tweets
        //algorithm [later can replace with izzhan algo
        Collections.reverse(activeTweets);

        List<TweetWithUsername> realTweets = new ArrayList<>();
        for (Tweet tweet : activeTweets) {
            User user = userRepository.findById(tweet.getUserId()).orElse(null);
            if (user != null) {
//                System.out.println("jumpa siakkk");
                TweetWithUsername tweetWithUsername = new TweetWithUsername(
                        user.getUsername(),
                        tweet.getTweetId(),
                        tweet.getContent(),
                        tweet.getUserId(),
                        tweet.isStatusDelete(),
                        tweet.getLikeUserIds(),
                        tweet.getHashtags()
                );
                realTweets.add(tweetWithUsername);
            }
        }

        return realTweets;
    }

    public List<TweetWithUsername> getAllUndeletedTweets() {
        List<Tweet> tweets = tweetRepository.findAll();
        //find the deleted tweet to exlude it
        List<Tweet> activeTweets = tweetRepository.findByStatusDeleteFalse();

//        List<Tweet> activeTweets = new ArrayList<>();
//        // Iterate through each tweet
//        for (Tweet tweet : tweets) {
//            // Check if the tweet is not deleted
//            if (!tweet.isStatusDelete()) {
//                // Add the tweet to the list of active tweets
//                activeTweets.add(tweet);
//            }
//        }
        //algorithm, later can replace with izzhan algo
        Collections.reverse(activeTweets);

        List<TweetWithUsername> realTweets = new ArrayList<>();
        for (Tweet tweet : activeTweets) {
            User user = userRepository.findById(tweet.getUserId()).orElse(null);
            if (user != null) {
//                System.out.println("jumpa siakkk");
                TweetWithUsername tweetWithUsername = new TweetWithUsername(
                        user.getUsername(),
                        tweet.getTweetId(),
                        tweet.getContent(),
                        tweet.getUserId(),
                        tweet.isStatusDelete(),
                        tweet.getLikeUserIds(),
                        tweet.getHashtags()
                );
                realTweets.add(tweetWithUsername);
            }
        }

        return realTweets;

    }

    public List<TweetWithUsername> getAllRecommendedTweets(String id) {
        Optional<RecommendedTweets> recTweets = recTweetsRepo.findByUserId(id);

        //get all the recommendedTweets
        if (recTweets.isPresent()) {
            RecommendedTweets recommend = recTweets.get();
            //get and store all the list of tweetIds
            List<String> allRecommendedTweetIds = recommend.getTweetIds();

            //for debugging purpose
            for (int i = 0; i < allRecommendedTweetIds.size(); i++) {
                System.out.println(i + ": " + allRecommendedTweetIds.get(i));
            }

            List<Tweet> tweets = tweetRepository.findAll();
//        //find the deleted tweet to exlude it
            List<Tweet> activeTweets = new ArrayList<>();
//
            // Filtering the deleted tweets
            for (Tweet tweet : tweets) {
                // Check if the tweet is not deleted
                if (!tweet.isStatusDelete()) {
                    // Add the tweet to the list of active tweets
                    activeTweets.add(tweet);
                }
            }

            //reversing the tweet to prioritize the first
            Collections.reverse(activeTweets);
//
//        
            List<TweetWithUsername> realTweets = new ArrayList<>();
            for (Tweet tweet : activeTweets) {
                User user = userRepository.findById(tweet.getUserId()).orElse(null);
                if (user != null) {
                    System.out.println("jumpa siakkk");
                    TweetWithUsername tweetWithUsername = new TweetWithUsername(
                            user.getUsername(),
                            tweet.getTweetId(),
                            tweet.getContent(),
                            tweet.getUserId(),
                            tweet.isStatusDelete(),
                            tweet.getLikeUserIds(),
                            tweet.getHashtags()
                    );
                    if (allRecommendedTweetIds.contains(tweet.getTweetId())) {
                        realTweets.add(tweetWithUsername);
                    }
                }
            }

            return realTweets;
        } else {
            return getAllUndeletedTweets();
        }

    }

    public List<TweetWithUsername> getPersonalTweets(String userId) {
        List<Tweet> tweets = tweetRepository.findAll();
        //find the deleted tweet to exlude it
        List<Tweet> activeTweets = new ArrayList<>();

        // Iterate through each tweet
        for (Tweet tweet : tweets) {
            // Check if the tweet is not deleted
            if (tweet != null && tweet.getUserId() != null && tweet.getUserId().equals(userId)) {
                // Add the tweet to the list of active tweets
                if (!tweet.isStatusDelete()) {
                    // Add the tweet to the list of active tweets
                    activeTweets.add(tweet);
                }
            }
        }

        //algorithm, later can replace with izzhan algo
        Collections.reverse(activeTweets);

        List<TweetWithUsername> realTweets = new ArrayList<>();
        for (Tweet tweet : activeTweets) {
            User user = userRepository.findById(tweet.getUserId()).orElse(null);
            if (user != null) {
//                System.out.println("jumpa siakkk");
                TweetWithUsername tweetWithUsername = new TweetWithUsername(
                        user.getUsername(),
                        tweet.getTweetId(),
                        tweet.getContent(),
                        tweet.getUserId(),
                        tweet.isStatusDelete(),
                        tweet.getLikeUserIds(),
                        tweet.getHashtags()
                );
                realTweets.add(tweetWithUsername);
            }
        }

        return realTweets;
    }

    public boolean checkIfLikedByUser(String tweetId, String userId) {
        Optional<Tweet> t = tweetRepository.findByTweetId(tweetId);
        if (t.isPresent()) {
            Tweet tweet = t.get();
            List<String> userIds = tweet.getLikeUserIds();
            if (userIds.contains(userId)) {
                return true;
            }
        }
        return false;
    }

    public List<TweetWithUsername> getTweets() {
        List<TweetWithUsername> tweets = getAllUndeletedTweets();
//        List<TweetWithUsername> batch = new ArrayList<>();
//        List<List<TweetWithUsername>> batches = new ArrayList<>();
//        int startCounter = 0;
//        int endCounter = number;
//
//        while (startCounter < tweets.size()) {
//            batch = new ArrayList<>();
//
//            for (int i = startCounter; i < endCounter && i < tweets.size(); i++) {
//                batch.add(tweets.get(i));
//            }
//
//            if (!batch.isEmpty()) {
//                batches.add(batch);
//            }
//
//            startCounter += number;
//            endCounter += number;
//        }

        return tweets;
    }

    public List<CommentWithUsername> getPersonalComments(String userId) {
        List<Comment> comments = commentRepository.findAll();
        //find the deleted tweet to exlude it
        List<Comment> activeComments = new ArrayList<>();

        // Iterate through each tweet
        for (Comment comment : comments) {
            // Check if the tweet is not deleted
            if (comment != null && comment.getUserId() != null && comment.getUserId().equals(userId)) {
                // Add the tweet to the list of active tweets
                if (!comment.isStatusDelete()) {
                    // Add the tweet to the list of active tweets
                    activeComments.add(comment);
                }
            }
        }

        //algorithm, later can replace with izzhan algo
        Collections.reverse(activeComments);

        List<CommentWithUsername> realComments = new ArrayList<>();
        for (Comment comment : activeComments) {
            User user = userRepository.findById(comment.getUserId()).orElse(null);
            if (user != null) {
//                System.out.println("jumpa siakkk");
                CommentWithUsername commentWithUsername = new CommentWithUsername(
                        user.getUsername(),
                        comment.getCommentId(),
                        comment.getParentId(),
                        comment.getContent(),
                        comment.getUserId(),
                        comment.isStatusDelete(),
                        comment.getLikeUserIds(),
                        comment.getHashtags()
                );
                realComments.add(commentWithUsername);
            }
        }

        return realComments;
    }

    public List<CommentWithUsername> getCommentsByParentId(String parentId) {
        // Retrieve comments with the specified parent ID
        List<Comment> comments = commentRepository.findByParentIdAndStatusDeleteFalse(parentId);

        List<Comment> activeComments = new ArrayList<>();

        // Iterate through each tweet and add only those that are not deleted to the activeTweets list
        for (Comment comment : comments) {
            if (!comment.isStatusDelete()) {
                activeComments.add(comment);
            }
        }

        // Return the list of active tweets
        //algorithm [later can replace with izzhan algo
        Collections.reverse(activeComments);

        List<CommentWithUsername> realComments = new ArrayList<>();
        for (Comment comment : activeComments) {
            User user = userRepository.findById(comment.getUserId()).orElse(null);
            if (user != null) {
//                System.out.println("jumpa siakkk");
                CommentWithUsername commentWithUsername = new CommentWithUsername(
                        user.getUsername(),
                        comment.getCommentId(),
                        comment.getParentId(),
                        comment.getContent(),
                        comment.getUserId(),
                        comment.isStatusDelete(),
                        comment.getLikeUserIds(),
                        comment.getHashtags()
                );
                realComments.add(commentWithUsername);
            }
        }

        return realComments;
    }

    ////

    /*public List<Tweet> getContents(String keyword) {
        
        // kena lalu izzhan punya algorithm then baru return list of suggested tweets
    }
    
    public List<Tweet> getLikedTweets() {
        
        // user ada array of tweetID yang dia like, so kita loop each tweetID and display the content
        
        //note - kena statusDelete tu dulu
        
    }
    
    public List<Tweet> getUserTweets() {
        
        // sama macam liked tweets, user tu ada tweetID yang dia dah post, so kita loopkan setiap tu then ambik sontent dia
        
        
        //note - kena statusDelete tu dulu
    }*/

    public Object getSingleTweetByParentId(String parentId) {
        Optional<Tweet> t = tweetRepository.findById(parentId);
        if(t.isPresent()){
            Tweet tweet = t.get();
            TweetWithUsername tweetWithUsername = null;
            User user = userRepository.findById(tweet.getUserId()).orElse(null);
            if (user != null) {
                tweetWithUsername = new TweetWithUsername(
                        user.getUsername(),
                        tweet.getTweetId(),
                        tweet.getContent(),
                        tweet.getUserId(),
                        tweet.isStatusDelete(),
                        tweet.getLikeUserIds(),
                        tweet.getHashtags()
                );
                return tweetWithUsername;
            }else{
                System.out.println("user is null");
                return null;
            }
        }
        
        
        System.out.println("tweet is not found");
        
        
        //this indicate that this is a comment instead of tweet
        Optional<Comment> c = commentRepository.findById(parentId);
        if(c.isPresent()){
            Comment comment = c.get();
            CommentWithUsername commentWithUsername = null;
            User user = userRepository.findById(comment.getUserId()).orElse(null);
            if (user != null) {
                commentWithUsername = new CommentWithUsername(
                        user.getUsername(),
                        comment.getCommentId(),
                        comment.getParentId(),
                        comment.getContent(),
                        comment.getUserId(),
                        comment.isStatusDelete(),
                        comment.getLikeUserIds(),
                        comment.getHashtags()
                );
                return commentWithUsername;
            }else{
                System.out.println("user is null");
                return null;
            }
        }
        System.out.println("comment is also not found");
        return null;
    }
}
