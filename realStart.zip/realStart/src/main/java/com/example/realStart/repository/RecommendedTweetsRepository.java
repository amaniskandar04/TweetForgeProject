/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.example.realStart.repository;

import com.example.realStart.model.RecommendedTweets;
import java.util.List;
import java.util.Optional;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
/**
 *
 * @author bottl
 */
@Repository
public interface RecommendedTweetsRepository extends MongoRepository<RecommendedTweets, String>{
    
    Optional<RecommendedTweets> findByUserId(String id);
}
