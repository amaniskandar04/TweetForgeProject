/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.service;

import com.example.realStart.PostBody.TweetWithUsername;
import com.example.realStart.RecBase.Constants;

import com.example.realStart.model.RecommendedTweets;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.realStart.repository.RecommendedTweetsRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.bson.types.ObjectId;
import com.example.realStart.model.RecommendedTweets;
import com.example.realStart.model.Tweet;
import com.example.realStart.model.User;
import com.example.realStart.repository.UserRepository;
import com.example.realStart.service.TweetService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import org.springframework.scheduling.annotation.Scheduled;
//import org.jgrapht.Graph;
//import org.jgrapht.graph.DefaultEdge;

/**
 *
 * @author bottl
 */
@Service
public class RecommendedTweetsService {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private MongoTemplate mongoTemplate;
    
    @Autowired
    private RecommendedTweetsRepository recTweetsRepo;
    
    @Autowired
    TweetService tweetService;
    
    @Autowired
    private UserRepository userRepo;
    
    private boolean isContentRec;
//    private Graph<Node, DefaultEdge> interestGraph;
    private User currentUser;
    private Constants constant = new Constants();
    private int index = -1;
    
    public User getCurrentUser(){
        return currentUser;
    }
    
    public void obtainCurrentUser() {
//        CurrentUser user = new CurrentUser();
//        currentUser = user.getCurrentUser();
        currentUser = userService.getUserData("aman"); //temporaary to test
        System.out.println("retarded");
    }
    public void obtainCurrentUser(User user){
        currentUser = user;
        System.out.println("name" + currentUser.getUsername());
    }
    
    public Optional<TweetWithUsername> random(TweetWithUsername tweet) {
        return Optional.ofNullable(tweet);
    }
    
    public Optional<TweetWithUsername> contentBased(TweetWithUsername tweet) {
        Optional recTweet;
        
        if (!isContentRec) {
            recTweet = random(tweet);
        }
        else {
            double[] itemProfile = getItemProfile(tweet.getHashtags());
            double[] userProfile = getUserPreference();
            
            recTweet = Optional.ofNullable(cosineSimilarity(userProfile, itemProfile) <= 0.6 ? null : tweet);
        }
        
        return recTweet;
    }
    
//    public List<TweetWithUsername> getTweets() {
//        List<TweetWithUsername> tweets = tweetService.getTweets();
//        return tweets.get();
//    }
    
    public List<Optional<TweetWithUsername>> runContentRec(User user) {
//        currentUser = userService.getUserData("aman"); //temporary to test
        currentUser = userService.getUserData(user.getUsername());
//        System.out.println("current user is empty? :"+ currentUser.getUsername());
        Random rnd = new Random();
        List<TweetWithUsername> tweets = tweetService.getTweets();
        List<Optional<TweetWithUsername>> recTweets = new ArrayList<>();
        //System.out.println(tweets.size());
        
        for (TweetWithUsername tweet : tweets) {
//            System.out.println(tweet.getTweetId() + ": " + tweet.getContent());
//            System.out.println("runContentrec :"+currentUser.getUsername());
            if (tweet.getUserId().equals(currentUser.getId())) {
                continue;
//                recTweets.add(random(tweet));
//                System.out.println("user  id equal");
                //System.out.println(tweet.getTweetId() + " " + tweet.getContent());
            }
            else {
                if (Arrays.stream(getUserPreference()).sum() < 20 ) {
                    recTweets.add(random(tweet));
//                    for (double num : getUserPreference()) {
//                        System.out.print(num);
//                    }
                }
                else {
                    int state = rnd.nextInt(10);

                    if (state <= 7) {
                        isContentRec = true;
                    }
                    else {
                        isContentRec = false;
                    }
                    

                    recTweets.add(contentBased(tweet));
                    isContentRec = false;
                }
            }
        }
        
        Collections.shuffle(recTweets);
        
        List<TweetWithUsername> recentTweets = tweetService.getPersonalTweets(currentUser.getId());
        if (!recentTweets.isEmpty()) {
            recTweets.set(0, random(recentTweets.get(0)));
        }
        
        return recTweets;
    }
    
    public List<TweetWithUsername> removeNull(List<Optional<TweetWithUsername>> recTweets) {
        List<TweetWithUsername> tweets = new ArrayList<>();
        for (Optional<TweetWithUsername> recTweet : recTweets) {
            TweetWithUsername tweet = recTweet.orElse(null);
            if (Objects.nonNull(tweet)) {
                tweets.add(tweet);
            }
        }
        
        return tweets;
    }
    
    public void uploadRecTweets(List<Optional<TweetWithUsername>> recTweets){
        List<String> tweetIds = new ArrayList<>();
        for (Optional<TweetWithUsername> recTweet : recTweets) {
            TweetWithUsername tweet = recTweet.orElse(null);
            
            if (Objects.nonNull(tweet)) {
                String userId = currentUser.getId();
                String tweetId = tweet.getTweetId();
                
                Query query = new Query(Criteria.where("userId").is(userId));
                Update update = new Update().push("tweetIds", tweetId);
                mongoTemplate.upsert(query, update, RecommendedTweets.class);
            }
        }
    }
    
    public void resetRecTweets(User user) {
//        currentUser = userService.getUserData("aman"); //test
        
        currentUser = user;
        
        Query query = new Query(Criteria.where("userId").is(currentUser.getId()));
        Update update = new Update().set("tweetIds", new ArrayList<>());
        mongoTemplate.updateFirst(query, update, RecommendedTweets.class);
    }
    

    //graph delay first
    
    
    //private methods lie here
    private double sigmoidFunction(double number) {
        return 1.0 / (1.0 + Math.exp(-number));
    }
    
    private double cosineSimilarity(double[] userProfile, double[] itemProfile) {
        if (userProfile.length != itemProfile.length) {
            throw new IllegalArgumentException("Vectors are not the same length");
        }
        
        double nom = 0;
        double denomX = 0;
        double denomY = 0;
        
        for (int i = 0; i < userProfile.length; i++) {
            nom += userProfile[i] * itemProfile[i];
            denomX += Math.pow(userProfile[i], 2);
            denomY += Math.pow(itemProfile[i], 2);
        }
        
        double denom = Math.sqrt(denomX) * Math.sqrt(denomY);
        
        if (denom == 0) {
            return 1;
        }
        
        return nom / denom;
    }
    
    private double[] getItemProfile(List<String> hashtags) {
        String[] topics = constant.getTopics();
        double[] itemProfile = new double[constant.getTopics().length];
        List<String> listTopics = new ArrayList<>();
        Map<String, String[]> mappedHashtags = constant.getHashtags();
        
        if (hashtags == null) {
            return new double[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1};
        }
        
        for (int i = 0; i < hashtags.size(); i++) {
            String hashtag = hashtags.get(i);
            mappedHashtags.entrySet().forEach(entry -> {
                if (Arrays.stream(entry.getValue()).anyMatch(hashtag::equals)) {
                    listTopics.add(entry.getKey());
                    return;
                }
            });
        }
        
        for (int i = 0; i < topics.length; i++) {
            if (listTopics.contains(topics[i])) {
                itemProfile[i]++;
            }
        }
        
        return itemProfile;
    }
    
    private double[] getUserPreference() {
        List<Double> userLikes = new ArrayList<>();
        HashMap<String, Integer> userProfile = currentUser.getUserProfile();
        
        userProfile.entrySet().forEach(entry -> {
            userLikes.add(Double.parseDouble(entry.getValue().toString()));
        });
        
        IntFunction<Double[]> generator = size -> new Double[userLikes.size()];
        
        return Stream.of(userLikes.toArray(generator)).mapToDouble(Double::doubleValue).toArray();
    }
}
