/**
 *
 * @author mamirizzan
 */
package com.example.realStart.controller;

import com.example.realStart.PostBody.CommentReceived;
import com.example.realStart.PostBody.CommentWithUsername;
import com.example.realStart.model.Comment;
import com.example.realStart.PostBody.Keyword;

import com.example.realStart.model.Tweet;
import com.example.realStart.PostBody.TweetReceived;
import com.example.realStart.PostBody.TweetWithUsername;
import com.example.realStart.PostBody.UserId;

import com.example.realStart.PostBody.Username;

import com.example.realStart.model.User;
import com.example.realStart.service.TweetService;
import com.example.realStart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/tweets")
@CrossOrigin
public class TweetController {
    
    

    @Autowired
    private TweetService tweetService;

    @Autowired
    private UserService userService;

    @PostMapping("/post")
    public ResponseEntity<?> postTweet(@RequestBody TweetReceived t) {
        System.out.println("Hashtags: "+t.hashtags);
        Tweet tweet = tweetService.postTweet(t.content, t.userId, t.hashtags);
        return ResponseEntity.ok(tweet);
    }

    @PostMapping("/{tweetId}/like")
    public ResponseEntity<Object> likeTweet(@PathVariable String tweetId, @RequestBody UserId id) {

        tweetService.likeTweet(tweetId, id.getUserId()); //this is actually getId()
        return ResponseEntity.ok("Like succeed");
    }
    
    @PostMapping("/{tweetId}/unlike")
    public ResponseEntity<?> unlikeTweet(@PathVariable String tweetId, @RequestBody UserId id) {

        tweetService.unlikeTweet(tweetId, id.getUserId()); //this is actually getId()
        return ResponseEntity.ok("Unlike succeed");
    }

    @PutMapping("/{tweetId}")
    public ResponseEntity<Object> deleteTweet(@PathVariable String tweetId) {
        tweetService.deleteTweet(tweetId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{tweetId}/deleteLikePost")
    public ResponseEntity<Object> deleteLikePost(@PathVariable String tweetId, @RequestBody TweetReceived t) {
        tweetService.deleteLikePost(tweetId, t.userId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/addComment")
        public ResponseEntity<?> addComment(@RequestBody CommentReceived c) {
        System.out.println(c.userId);
        Comment comment = tweetService.addComment(c.content, c.userId, c.parentId, c.hashtags);
        return ResponseEntity.ok(comment);
    }
    
    @GetMapping("/byParentId/{parentId}")
    public ResponseEntity<List<CommentWithUsername>> getCommentsByParentId(@PathVariable String parentId) {
        List<CommentWithUsername> comments = tweetService.getCommentsByParentId(parentId);
        return ResponseEntity.ok(comments);
    }

    @PostMapping("/search")
    public List<TweetWithUsername> searchTweets(@RequestBody Keyword t) {
        return tweetService.searchTweets(t.getKeyword());
    }

    @GetMapping("/getAllTweets")
    public List<TweetWithUsername> getAllTweets() {
        return tweetService.getAllUndeletedTweets();
    }
    
    @GetMapping("/getAllRecommendedTweets/{id}")
    public List<TweetWithUsername> getAllRecommendedTweets(@PathVariable String id){
        return tweetService.getAllRecommendedTweets(id);
    }

    @PostMapping("/getAllPersonalTweets")
    public List<TweetWithUsername> getAllPersonalTweets(@RequestBody Username USER) {
        //get the userid from database
        User userData = userService.getUserData(USER.getUsername());
        System.out.println("User ID in personal tweet: " + userData.getId());
        String userId = userData.getId();
        
        

        return tweetService.getPersonalTweets(userId);
    }
    
    @PostMapping("/getAllPersonalComments")
    public List<CommentWithUsername> getAllPersonalComments(@RequestBody Username USER){
        User userData = userService.getUserData(USER.getUsername());
        String userId = userData.getId();
        
        return tweetService.getPersonalComments(userId);
    }
    
    

    @GetMapping("/{tweetId}/isLikedByUser/{userId}")
    public ResponseEntity<?> checkIfLikedByUser(@PathVariable String tweetId, @PathVariable String userId) {
        return ResponseEntity.ok(tweetService.checkIfLikedByUser(tweetId, userId));
    }
   
        

    @PutMapping("/comment/{tweetId}")
    public ResponseEntity<?> deleteComment(@PathVariable String tweetId) {
        tweetService.deleteComment(tweetId);
        return ResponseEntity.ok().build();
    }
    
    @PostMapping("/{commentId}/likeComment")
    public ResponseEntity<Object> likeComment(@PathVariable String commentId, @RequestBody UserId id) {

        tweetService.likeComment(commentId, id.getUserId()); //this is actually getId()
        return ResponseEntity.ok("Like comment succeed");
    }
    
    @PostMapping("/{commentId}/unlikeComment")
    public ResponseEntity<?> unlikeComment(@PathVariable String commentId, @RequestBody UserId id) {

        tweetService.unlikeComment(commentId, id.getUserId()); //this is actually getId()
        return ResponseEntity.ok("Unlike comment succeed");
    }
}
