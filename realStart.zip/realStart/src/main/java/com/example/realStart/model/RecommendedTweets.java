/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author bottl
 */
@Document(collection = "recommendedTweets")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecommendedTweets {
    
    @Id
    private String id;
    private String userId;
    private List<String> tweetIds;
    
    public RecommendedTweets(String userId, List<String> tweetIds) {
        this.userId = userId;
        this.tweetIds = tweetIds;
    }
    
    public RecommendedTweets(String userId) {
        this.userId = userId;
    }
}
