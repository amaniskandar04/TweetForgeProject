

/**
 *
 * @author mamirizzan
 */
package com.example.realStart.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection = "tweets")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Tweet {
    @Id
    private String tweetId;
    private String content;
    private String userId;
    private boolean statusDelete;
    private List<String> likeUserIds;
    private List<String> hashtags;


    public Tweet(String content, String userId,List<String> hashtags, List<String> likeUserIds) {
        this.content = content;
        this.userId = userId;
        this.likeUserIds=likeUserIds;
        this.hashtags=hashtags;
        this.statusDelete=false;
    }

    
}

