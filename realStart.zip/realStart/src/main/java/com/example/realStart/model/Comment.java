package com.example.realStart.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection = "comments")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Comment {
    @Id
    private String commentId;
    private String parentId; // Refers to the Tweet being commented on
    private String content;
    private String userId;
    private boolean statusDelete;
    private List<String> likeUserIds;
    private List<String> hashtags;

    public Comment(String content, String userId, String parentId, List<String> likeUserIds,List<String> hashtags) {
        this.content = content;
        this.userId = userId;
        this.parentId = parentId;
        this.likeUserIds = likeUserIds;
        this.statusDelete = false;
        this.hashtags=hashtags;
    }
}
