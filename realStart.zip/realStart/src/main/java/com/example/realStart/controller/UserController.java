/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.controller;

import com.example.realStart.PostBody.Description;
import com.example.realStart.PostBody.Login;
import com.example.realStart.PostBody.Registration;
import com.example.realStart.PostBody.Title;
import com.example.realStart.PostBody.UserProfilePicture;
import com.example.realStart.model.User;
import com.example.realStart.service.UserService;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author sawaz
 */

@RestController
@RequestMapping("/TweetForge")
@CrossOrigin
public class UserController {
    
    @Autowired
    UserService service;
    
    
    @GetMapping
    public String item(){
        return "Nigga";
    }
    
    
    
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody Registration register){
        System.out.println("Email:"+ register.getEmail());
        System.out.println("Username:"+ register.getUsername());
        System.out.println("Password:"+ register.getPassword());
        
        //check the password length
        if(!service.passwordChecker(register.getPassword())){
            
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Password must at least contain a digit, uppercase, lowercase and must be longer than 8 characters.");
        }
        
        //check if the username or email has already existed
        
        
        User user = service.registerUser(register);
        if(user!=null){
            return ResponseEntity.ok(user);
        }else{
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Registration failed: The account has already existed");
        }
        
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Login login){
        System.out.println(login.getUsername());
        System.out.println(login.getPassword());
        
        User userId = service.authenticate(login);
        //check if the username and password is in the mongodb database
        if (userId != null) {
            return ResponseEntity.ok(userId); // Return user ID
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(false);
        }
    }
    
    @GetMapping("/getAllUsers")
    public ResponseEntity<?> getAllUsers(){
        return ResponseEntity.ok(service.getAllUsers());
    }
    
    @PostMapping("/add")
    public ResponseEntity<?> add(@RequestBody User user){
        return ResponseEntity.ok(service.addAllTest(user));
        
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> findTheId(@PathVariable String id){
        System.out.println(id);
        return ResponseEntity.ok(service.idAvailable(id));
    }
    
    //New method nak set userProfile
    @PostMapping(value="/setUserPic",consumes="multipart/form-data")
    public ResponseEntity<?> userProfilePicture(@RequestParam("userId") String userId, @RequestParam(value="imageFile",required=false) MultipartFile imageFile) throws IOException{
        System.out.println(userId);
        System.out.println();
        User userReceived=service.getUser(userId);
        
        if(userReceived==null){
           return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User is not found");
        }
        System.out.println("user received: "+userReceived.getUsername());
        if(service.setUserProfilePicture(userReceived, imageFile)){
           return ResponseEntity.ok("The profile picture added successfully");
        }
        
        return ResponseEntity.status(HttpStatus.CONFLICT).build();
    }
    
    //New method untuk display userProfile
    @GetMapping("/{userId}/userPic")
    public ResponseEntity<?> getUserProfilePicture(@PathVariable String userId){
        User userReceived=service.getUser(userId);
        
        if(userReceived==null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("The user is not found");
        }
        UserProfilePicture image=userReceived.getProfileImage();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "Image file name: "+image.getNameImage())
                .contentType(MediaType.valueOf(image.getContentType()))
                .body(image.getData());
    }
   
    @PostMapping("/{userId}/setTitle")
    public ResponseEntity<?> setTitle(@PathVariable String userId, @RequestBody Title t){
        return ResponseEntity.ok(service.saveTitle(userId, t.getTitle()));
    }
    
    @PostMapping("/{userId}/setDescription")
    public ResponseEntity<?> setDescription(@PathVariable String userId, @RequestBody Description d){
        
        
        return ResponseEntity.ok(service.saveDescription(userId, d.getDescription()));
    }
 
}
