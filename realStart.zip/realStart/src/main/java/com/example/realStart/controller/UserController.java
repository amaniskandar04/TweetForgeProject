/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.controller;

import com.example.realStart.PostBody.Login;
import com.example.realStart.PostBody.Registration;
import com.example.realStart.model.User;
import com.example.realStart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author sawaz
 */

@RestController
@RequestMapping("/TweetForge")
@CrossOrigin
public class UserController {
    
    @Autowired
    UserService service;
    
    
    @GetMapping
    public String item(){
        return "Nigga";
    }
    
    
    
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody Registration register){
        System.out.println("Email:"+ register.getEmail());
        System.out.println("Username:"+ register.getUsername());
        System.out.println("Password:"+ register.getPassword());
        
        //check the password length
        if(!service.passwordChecker(register.getPassword())){
            
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Password must at least contain a digit, uppercase, lowercase and must be longer than 8 characters.");
        }
        
        //check if the username or email has already existed
        
        
        User user = service.registerUser(register);
        if(user!=null){
            return ResponseEntity.ok(user);
        }else{
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Registration failed: The account has already existed");
        }
        
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Login login){
        System.out.println(login.getUsername());
        System.out.println(login.getPassword());
        
        User userId = service.authenticate(login);
        //check if the username and password is in the mongodb database
        if (userId != null) {
            return ResponseEntity.ok(userId); // Return user ID
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(false);
        }
    }
    
    @GetMapping("/getAllUsers")
    public ResponseEntity<?> getAllUsers(){
        return ResponseEntity.ok(service.getAllUsers());
    }
    
    @PostMapping("/add")
    public ResponseEntity<?> add(@RequestBody User user){
        return ResponseEntity.ok(service.addAllTest(user));
        
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> findTheId(@PathVariable String id){
        System.out.println(id);
        return ResponseEntity.ok(service.idAvailable(id));
    }

}
