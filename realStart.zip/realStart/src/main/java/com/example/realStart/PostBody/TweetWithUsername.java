/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.PostBody;

import java.util.List;
import lombok.Data;

/**
 *
 * @author sawaz
 */
@Data
public class TweetWithUsername {
    private String username;
    private String tweetId;
    private String content;
    private String userId;
    private boolean statusDelete;
    private List<String> likeUserIds;
        private List<String> hashtags;

    public TweetWithUsername(String username, String tweetId, String content, String userId, boolean statusDelete, List<String> likeUserIds, List<String> hashtags) {
        this.username = username;
        this.tweetId = tweetId;
        this.content = content;
        this.userId = userId;
        this.statusDelete = statusDelete;
        this.likeUserIds = likeUserIds;
        this.hashtags = hashtags;
    }
    
    
}
