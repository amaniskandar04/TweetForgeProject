/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.service;

import com.example.realStart.PostBody.Login;
import com.example.realStart.PostBody.Registration;

import com.example.realStart.model.User;
import com.example.realStart.repository.UserRepository;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

/**
 *
 * @author sawaz
 */
@Service
public class UserService {
    
    @Autowired
    UserRepository userRepo;
    
    @Autowired
    private MongoTemplate mongoTemplate;
    
     
    
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int SALT_LENGTH = 12; 
    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    
    public static String generateSalt() {
        Random random = new Random();
        StringBuilder salt = new StringBuilder(SALT_LENGTH);

        for (int i = 0; i < SALT_LENGTH; i++) {
            int index = random.nextInt(CHARACTERS.length());
            salt.append(CHARACTERS.charAt(index));
        }

        return salt.toString();
    }
    
    public static boolean hasUppercaseAndLowercaseAndDigit(String input) {
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasDigit = false;

        for (char c : input.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(c)) {
                hasLowercase = true;
            } else if (Character.isDigit(c)){
                hasDigit = true;
            }
            // If both conditions are met, we can stop early
            if (hasUppercase && hasLowercase && hasDigit) {
                return true;
            }
        }
        return hasUppercase && hasLowercase;
    }
    
    public boolean passwordChecker(String password){
        if(password.length()>8 && hasUppercaseAndLowercaseAndDigit(password)){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean isUniqueUsername(String username){
        if(userRepo.findByUsername(username).isPresent()){
            return false;
        }
        return true;
    }
    
    
    public User addAllTest(User user){
        return userRepo.save(user);
    }
    
    public User registerUser(Registration register){
        String username = register.getUsername();
        String email = register.getEmail();
        String password = register.getPassword();
        
        Optional<User> user1 = userRepo.findByUsername(username);
        Optional<User> user2 = userRepo.findByEmail(email);
        
        
        if(!user1.isPresent() && !user2.isPresent()){
            System.out.println("username: "+username);
            
            
            
            String salt = generateSalt();
            password = password + salt;
            String hashedPassword = passwordEncoder.encode(password);
            /*
            how to store password in the database
            1. take the password
            2. add a salt into that password
            3. hash the password
            4. store the password in the mongodb using the function below
            
            how to fetch for login:
            1. fetch the username, check if username existed in the database
            2. if username existed, take the password and unhashed it, unsalt it.
            3. compare the unhashed and unsalted password with the inserted user password
            4. if same then can log in
            
            */
            
            
            User newUser = new User(register.getUsername(),register.getEmail(),hashedPassword, salt);
            userRepo.save(newUser);
            return newUser;
        }else{
            
            
            System.out.println("User has already existed");
            return null;
        }
        
    }
    
    
    
    public boolean checkUser(Login login){
        Optional<User> user = userRepo.findByUsernameAndPassword(login.getUsername(), login.getPassword());
        return user.isPresent();
    }
    
    public User authenticate(Login login){
        Optional<User> user = userRepo.findByUsername(login.getUsername());
        if(user.isPresent()){
            User acc = user.get();
            
            //salt the password
            String salt = acc.getSalt();
            String testPass = login.getPassword() + salt;
            
            System.out.println("password entered: "+ testPass);
            System.out.println("password database: "+acc.getPassword());
            boolean passwordMatch = passwordEncoder.matches(testPass, acc.getPassword());
            if(passwordMatch){
                
                return acc;
            }else{
                System.out.println("User failed to login");
                return null;
            }
            
            
        }else{
            System.out.println("User failed to login");
            return null;
        }
    }
    
    public List<User> getAllUsers(){
        return userRepo.findAll();
    }
    
    public User getUserData(String username){
        Optional<User> user = userRepo.findByUsername(username);
        if(user.isPresent()){
            User userData = user.get();
            return userData;
        }else{
            
            return null;
        }
    }
    
    public boolean idAvailable(String id){
        Optional<User> x = userRepo.findById(id);
        return (x.isPresent());
    }
    
    public void updateUserProfile(String userId, List<String> topics, String action) {
        for (String topic : topics) {
            Query query = new Query(Criteria.where("_id").is(userId));
            Update update = null;
            if (action.equals("like")) {
                System.out.println("success inside");
                update = new Update().inc("userProfile." + topic, 1);
            }
            else if (action.equals("unlike")) {
                System.out.println("success succeed for unlike");
                update = new Update().inc("userProfile." + topic, -1);
            }
            
            mongoTemplate.updateFirst(query, update, User.class);
        }
        
        
    }
    
    
    
}
