

/**
 *
 * @author mamirizzan
 */

package com.example.realStart.repository;


import com.example.realStart.model.Tweet;
import java.util.List;
import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TweetRepository extends MongoRepository<Tweet, String> {
    
    Optional<Tweet> findByTweetId(String tweetId);
    List<Tweet> findByStatusDeleteFalse();
}

