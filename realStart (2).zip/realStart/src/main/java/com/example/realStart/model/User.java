/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author sawaz
 */

@Document(collection = "user")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    
    @Id
    private String id;
    private String username;
    private String description;
    private String email;
    private String password;
    private String salt;
    private String image;
    private List<String> likeTweetIds;
    private List<String> tweetIds;
    private List<String> commentIDs; 
    private HashMap<String, Integer> userProfile;
    
    
    public User(String username, String email, String password){
        this.username = username;
        this.email = email;
        this.password = password;
        
        this.description = null;
        this.image = null;
        this.tweetIds = new ArrayList<>();
        this.likeTweetIds=new ArrayList<>();
    }
    
    public User(String username, String email, String password, String salt){
        this.username = username;
        this.email = email;
        this.password = password;
        this.salt = salt;
        this.userProfile = new HashMap<>();
        this.userProfile.put("Art", 0);
        this.userProfile.put("Entertainment", 0);
        this.userProfile.put("Science", 0);
        this.userProfile.put("Fashion & Beauty", 0);
        this.userProfile.put("Health & Fitness", 0);
        this.userProfile.put("Travel & Culture", 0);
        this.userProfile.put("Animals", 0);
        this.userProfile.put("Technology", 0);
        this.userProfile.put("Education", 0);
        this.userProfile.put("News", 0);
        this.userProfile.put("Politics", 0);
        this.userProfile.put("Gaming", 0);
        this.userProfile.put("Sports", 0);
        this.userProfile.put("Business", 0);
        this.userProfile.put("Food", 0);
        this.userProfile.put("Miscellaneous", 0);
        this.description = null;
        this.image = null;
        this.tweetIds = new ArrayList<>();
        this.likeTweetIds=new ArrayList<>();
    }
    
    public User(String username, String email, String password, String salt, HashMap<String, Integer> userProfile){
        this.username = username;
        this.email = email;
        this.password = password;
        this.salt = salt;
      
        this.description = null;
        this.image = null;
        this.tweetIds = new ArrayList<>();
        this.likeTweetIds=new ArrayList<>();
        this.userProfile = userProfile;
        
    }
    
    
    
    
}
