/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.RecBase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author bottl
 */
public class Constants {
public Map<String, String[]> getHashtags() {
        Map<String, String[]> hashtags = new HashMap<>();

        hashtags.put("Sports", new String[]{"#sportslife", "#athlete", "#gameday", "#sportsfan", "#nevergiveup",
            "#mvp", "#fitness", "#motivation", "#competition", "#workout", "#teamplayer", "#strong", "#olympics",
            "#championsleague", "#worldcup", "#goal", "#hockey", "#tennis", "#cycling", "#esports", "#marathon", "#training"});

        hashtags.put("Technology", new String[]{"#technology", "#techlife", "#future", "#innovation", "#gadget",
            "#artificialintelligence", "#ai", "#machinelearning", "#coding", "#programming", "#software", "#app",
            "#cybersecurity", "#internet", "#gadgets", "#vr", "#virtualreality", "#ar", "#augmentedreality",
            "#iot", "#internetofthings"});

        hashtags.put("Art", new String[]{"#art", "#artist", "#artwork", "#artoftheday", "#artofinstagram",
            "#artoftheweek", "#creative", "#painting", "#drawing", "#illustration", "#photography",
            "#sculpture", "#digitalart", "#mixedmedia", "#contemporaryart", "#abstractart", "#artlover",
            "#artistsoninstagram", "#artshare", "#artoftheinternet", "#therapy", "#newgear", "#excited", "#gallery", "#inspiration"});

        hashtags.put("Entertainment", new String[]{"#entertainment", "#entertainmentnews", "#celebrity",
            "#music", "#movies", "#tvshow", "#concert", "#comedy", "#art", "#dance", "#reading", "#gaming",
            "#funny", "#memes", "#laugh", "#lifestyle", "#relax", "#weekendvibes", "#fun", "#netflixandchill",
            "#bookstagram", "#weekendplans"});

        hashtags.put("Gaming", new String[]{"#gamer", "#gaming", "#gamingcommunity", "#gamersofinstagram",
            "#gamersoftiktok", "#gamerslife", "#game", "#esports", "#gamingsetup", "#pcgaming", "#retrogaming",
            "#mobilegaming", "#livestreaming", "#twitch", "#youtubegaming", "#letsplay", "#gamingmemes",
            "#gamergirl", "#gamerguy", "#achievementunlocked"});

        hashtags.put("Politics", new String[]{"#politics", "#government", "#election", "#voting", "#activism",
            "#socialjustice", "#currentaffairs", "#policy", "#debate", "#democracy", "#humanrights", "#protest",
            "#legislation", "#campaign", "#worldpolitics", "#politicalmemes", "#politicalcartoon", "#patriot",
            "#vote", "#impeachment", "#representation"});

        hashtags.put("Business", new String[]{"#entrepreneur", "#businesslife", "#marketing", "#startup",
            "#success", "#smallbusiness", "#growth", "#motivation", "#hustle", "#businessowner", "#leadership",
            "#innovation", "#womeninbusiness", "#entrepreneurlife", "#socialmedia", "#businesstips", "#finance",
            "#branding", "#network", "#productivity"});

        hashtags.put("Travel & Culture", new String[]{"#culture", "#travel", "#travelgram", "#travelphotography",
            "#instatravel", "#wanderlust", "#explore", "#adventure", "#worldtraveler", "#travelblogger",
            "#traveltheworld", "#vacation", "#tourism", "#culturalexchange", "#bucketlist", "#travelholic",
            "#globetrotter", "#trip", "#backpacktravel", "#traveldeeper", "#citylife", "#peaceful", "#nature"});

        hashtags.put("Science", new String[]{"#science", "#scientist", "#sciencelife", "#sciencelover", "#STEM",
            "#discovery", "#research", "#innovation", "#technology", "#future", "#physics", "#chemistry",
            "#biology", "#astronomy", "#space", "#environment", "#climatechange", "#nature", "#engineering",
            "#math"});

        hashtags.put("Food", new String[]{"#food", "#foodphotography", "#foodie", "#foodlover", "#yummy",
            "#delicious", "#foodstagram", "#foodgasm", "#instafood", "#homemade", "#foodblog", "#foodporn",
            "#healthyfood", "#eating", "#foodpic", "#foodpics", "#foodcoma", "#foodgram", "#chef", "#cooking"});

        hashtags.put("Animals", new String[]{"#animals", "#animallover", "#pets", "#wildlife", "#dog", "#cat",
            "#petstagram", "#dogsofinstagram", "#catsofinstagram", "#cutedogs", "#cutecats",
            "#animalsofinstagram", "#petlife", "#wildlifephotography", "#animalphotography", "#doggo",
            "#floof", "#kitty", "#petsofig", "#rescuedog", "#rescuecat", "#puppy", "#cute"});

        hashtags.put("Education", new String[]{"#education", "#studentlife", "#learning", "#studygram",
            "#teacherlife", "#backtoschool", "#knowledge", "#motivation", "#future", "#school", "#study",
            "#college", "#university", "#educationmatters", "#learn", "#graduate", "#classroom",
            "#educationforall", "#elearning", "#studysmart", "#spanish", "#language"});

        hashtags.put("Fashion & Beauty", new String[]{"#fashion", "#beauty", "#ootd", "#style", "#makeup",
            "#hair", "#fashionista", "#beautylover", "#glam", "#instastyle", "#instagood", "#fashionblogger",
            "#beautyguru", "#makeupaddict", "#hairgoals", "#nails", "#skincare", "#selfie", "#model",
            "#streetstyle"});

        hashtags.put("Health & Fitness", new String[]{"#health", "#fitness", "#healthylifestyle", "#workout",
            "#gym", "#motivation", "#fitfam", "#healthyliving", "#wellness", "#weightloss", "#gainz", "#yoga",
            "#nutrition", "#exercise", "#muscle", "#healthyfood", "#eatclean", "#strengthtraining",
            "#cardio", "#mentalhealth", "#marathon", "#achievement", "#morningroutine"});

        hashtags.put("News", new String[]{"#breakingnews", "#currentaffairs", "#newsupdate", "#worldnews",
            "#headline", "#inthenews", "#newsoftheday", "#journalism", "#globalnews", "#stayinformed",
            "#newsworthy", "#newsjunkie", "#ontheground", "#investigativejournalism", "#newsanalysis",
            "#newscoverage", "#newsreport", "#newsflash", "#topstory"});
        
        hashtags.put("Miscellaneous", new String[]{"#lifestyle", "#coffee", "#weekendvibes",
            "#weekend", "#fun", "#relax", "#python", "#programming",
            "#sunset", "#timeflies", "#june", "#summer",
            "#AI", "#technology", "#rainyday", "#cozy", "#weather",
            "#nostalgia", "#memories", "#throwback", "#naturewalk", "#outdoors", "#wellness",
            "#favorites", "#guitar", "#learning", "#familytime", "#downtime", "#gardening", "#hobby", "#stargazing",
            "#relaxation", "#documentary", "#inspiration", "#watching", "#booklover", "#tea", "#rainbow", "#beautiful", "miscellaneous"});

        return hashtags;
    }
    
    public String[] getTopics() {
        String[] topics = {"Sports", "Technology", "Art", "Entertainment", "Gaming", "Politics", "Business",
            "Travel & Culture", "Science", "Food", "Animals", "Education", "Fashion & Beauty", "Health & Fitness",
            "News", "Miscellaneous"};

        return topics;
    }
    
    public List<String> getAssociatedTopics(List<String> hashtags) {
        List<String> topics = new ArrayList<>();
        Map<String, String[]> overallHashtags = getHashtags();
        
        if(hashtags == null){
            topics.add("Miscellaneous");
            return topics;
        }
        for (String hashtag : hashtags) {
            overallHashtags.entrySet().forEach(entry -> {
                if (Arrays.stream(entry.getValue()).anyMatch(hashtag::equals)) {
                    topics.add(entry.getKey());
                    return;
                }
            });
        }
        
        return topics;
    }
}
