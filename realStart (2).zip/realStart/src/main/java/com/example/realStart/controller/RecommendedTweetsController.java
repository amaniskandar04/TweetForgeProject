
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.controller;

import com.example.realStart.PostBody.TweetWithUsername;
import com.example.realStart.model.Tweet;
import com.example.realStart.model.User;
import com.example.realStart.service.RecommendedTweetsService;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author bottl
 */

@RestController
@RequestMapping("/recTweets")
@CrossOrigin
public class RecommendedTweetsController {
    
    @Autowired
    private RecommendedTweetsService recTweetsService;
    
    
//    @GetMapping("/run")
//    public ResponseEntity<?> runContentRecommendation() {
//        recTweetsService.obtainCurrentUser();
//        System.out.println("name: "+recTweetsService.getCurrentUser().getName());
//        //List<TweetWithUsername> tweets = recTweetsService.getTweets();
//        return ResponseEntity.ok(recTweetsService.runContentRec());
//    }
//    
//    
    
    @PostMapping("/upload")
    public ResponseEntity<?> uploadRecommendedTweets(@RequestBody User user) {
        recTweetsService.obtainCurrentUser(user);
        
        List<Optional<TweetWithUsername>> recTweets = recTweetsService.runContentRec(user);
        List<TweetWithUsername> tweets = recTweetsService.removeNull(recTweets);
//        recTweetsService.uploadRecTweets(recTweets);
//        System.out.println("oi oi oi");
        
        
        
        return ResponseEntity.ok(tweets);
    }
    
    //refresh/leave app
    @PutMapping("/resetRecTweets")
    public ResponseEntity<?> resetRecommendedTweets(@RequestBody User user) {
        recTweetsService.resetRecTweets(user);
        return ResponseEntity.ok("Succeed");
    }
    
    
    
}
