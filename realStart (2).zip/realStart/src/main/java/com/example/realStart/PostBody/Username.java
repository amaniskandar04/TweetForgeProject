/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.realStart.PostBody;

import lombok.Data;

/**
 *
 * @author sawaz
 */
@Data
public class Username {
    private String username;
}
