

/**
 *
 * @author mamirizzan
 */
package com.example.realStart.repository;


import com.example.realStart.model.Comment;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CommentRepository extends MongoRepository<Comment, String> {

    public List<Comment> findByParentIdAndStatusDeleteFalse(String parentId);
}

